﻿using OrgHack.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrgHack.Models
{

    public enum Roles
    {
        Organizer = 1,
        GroupLead,
        GroupMember,
        Coordinators
    }
    public class MemberRoles
    {
        public static int getUserRole(string email)
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            int role = (from employees in orgHackEntities.Employees
                                join rolemapper in orgHackEntities.EmployeeRoleMappers on employees.EmpId equals rolemapper.EmpId
                                where employees.IsActive.Value == true && employees.Email == email
                                select rolemapper.RoleId.Value).FirstOrDefault();

            return role;
        }
    }
}