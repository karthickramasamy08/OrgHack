﻿using OrgHack.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace OrgHack.Models
{
    public class Login
    {       
            [Required]
            [Display(Name = "Username or Email address")]
            public string EmailId { get; set; }

            [Required]
            [DataType(DataType.Password)]
            [Display(Name = "Password")]
            public string Password { get; set; }

            [Display(Name = "Remember me?")]
            public bool RememberMe { get; set; }
            public int id { get; set; }
            public ChangePassword changePassword{ get; set; }
            public string ReturnUrl { get; set; }

        public static int GetAuthenticatedUserDetails(string EmailId, string Password)
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            var employeeList = (from employee in orgHackEntities.Employees
                                where employee.IsActive.Value == true && employee.Email == EmailId && employee.Password == Password
                                select employee.EmpId).FirstOrDefault();
            return employeeList;

        }

    }

   


}