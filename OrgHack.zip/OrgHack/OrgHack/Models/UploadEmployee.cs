﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using Syncfusion.XlsIO;
using System.Data;
using OrgHack.Entity;

namespace OrgHack.Models
{
    public class UploadEmployeesinDB
    {
        public static string UploadDatafromExcel(Stream inputStream)
        {
            BulkUserResult bulkUserResultStatus = new BulkUserResult();
            string error = string.Empty;
            bool DeactivateUser = true;
            try
            {
                ExcelEngine excelEngine = new ExcelEngine();
                IApplication application = excelEngine.Excel;
                IWorkbook workbook = application.Workbooks.Open(inputStream, ExcelOpenType.Automatic);
                IWorksheet sheet = workbook.Worksheets[0];
                DataTable employeeDetails = sheet.ExportDataTable(sheet.UsedRange, ExcelExportDataTableOptions.ColumnNames);
                                          
                for (int row = 0; row < employeeDetails.Rows.Count; row++)
                {
                    Employee employee = null;
                    string role = null;
                    string errorMessage = string.Empty;
                    for (int col = 0; col < employeeDetails.Columns.Count; col++)
                    {
                        if (employee == null)
                        {
                            employee = new Employee();
                        }

                        var header = (employeeDetails.Columns[col].ColumnName.ToString()).Trim();
                        string data = (employeeDetails.Rows[row][col].ToString()).Trim();

                        switch (header)
                        {
                            case "EmployeeCode":
                                employee.EmployeeCode = data;
                                break;
                            case "Emailid":
                                employee.Email = data;
                                break;
                            case "Location":
                                employee.Location = data;
                                break;
                            case "Designation":
                                employee.Designation = data;
                                break;
                            case "EmployeeName":
                                employee.EmployeeName = data;
                                break;
                            case "Role":
                                role = data;
                                break;

                        }
                    }

                        using (var context = new OrgHackEntities())
                        {
                           if(DeactivateUser == true)
                           {
                            var previousemployees = (from Employee in context.Employees where Employee.IsActive.Value == true select Employee).ToList();
                            previousemployees.Where(x => x.IsActive.Value == true).ToList().ForEach(s => s.IsActive = false);
                            DeactivateUser = false;
                           }                           
                            employee.CreatedDate = DateTime.Now;
                            employee.ModifiedDate = DateTime.Now;
                            employee.Password = "Syncfusion@123";
                            employee.IsActive = true;
                            context.Employees.Add(employee);                                                

                        var employeeeId = (from employees in context.Employees where employees.IsActive.Value == true && employees.Email == employee.Email select employees.EmpId).FirstOrDefault();
                        EmployeeRoleMapper employeerole = new EmployeeRoleMapper();

                        if(role.Contains("General Manager")){                           
                            employeerole.EmpId = employeeeId;
                            employeerole.RoleId = (int)Models.Roles.Organizer;
                            employeerole.CreatedDate = DateTime.Now;
                            employeerole.ModifiedDate = DateTime.Now;
                            employeerole.IsActive = true;
                        }
                        else if (role.Contains("Manager"))
                        {                          
                            employeerole.EmpId = employeeeId;
                            employeerole.RoleId = (int)Models.Roles.Coordinators;
                            employeerole.CreatedDate = DateTime.Now;
                            employeerole.ModifiedDate = DateTime.Now;
                            employeerole.IsActive = true;
                        }
                        else
                        {                           
                            employeerole.EmpId = employeeeId;
                            employeerole.RoleId = (int)Models.Roles.GroupMember;
                            employeerole.CreatedDate = DateTime.Now;
                            employeerole.ModifiedDate = DateTime.Now;
                            employeerole.IsActive = true;
                        }
                        context.EmployeeRoleMappers.Add(employeerole);
                        context.SaveChanges();
                     }                        
                }          
                return "Successfully Uploaded";
            }
            catch(Exception ex)
            {
                return "An error occurred while processing. Please try again later.";
            }
        }

    }

    public class BulkUserResult
    {
        public string ErrorMessage { get; set; }
        public string FileName { get; set; }
    }

    public class EmployeeDetail
    {
        public string EmployeeCode { get; set; }
        public string Emailid { get; set; }
        public string Location { get; set; }
        public string Designation { get; set; }
        public string EmployeeName { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string Password { get; set; }
        public int RoleId { get; set; }
        public bool isActive { get; set; }
        public string Status { get; set; }
    }


}