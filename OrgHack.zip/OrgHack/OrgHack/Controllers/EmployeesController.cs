﻿using OrgHack.Entity;
using OrgHack.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrgHack.Controllers
{
    public class EmployeesController : Controller
    {
        [Authorize]
        public ActionResult AddUser()
        {
            return View("~/Views/Employees/AddEmployees.cshtml");
        }

        [Authorize]
        public JsonResult UploadEmployee(HttpPostedFileBase file)
        {
            bool result = false;
            string resultFileName = string.Empty;
            string validationMessage = string.Empty;
            try
            {
                if (Request.Files != null && Request.Files.Count > 0 && !String.IsNullOrWhiteSpace(Request.Files[0].FileName) && Request.Files[0].ContentLength > 0)
                {
                    file = Request.Files[0];
                    var ext = System.IO.Path.GetExtension(Request.Files[0].FileName);
                    if (ext == ".xls" || ext == ".xlsx")
                    {
                        byte[] fileBytes = new byte[file.ContentLength];
                        var data = file.InputStream.Read(fileBytes, 0, Convert.ToInt32(file.ContentLength));
                        var stream = new MemoryStream(fileBytes);                        
                        var res = UploadEmployeesinDB.UploadDatafromExcel(stream);
                        validationMessage = res;
                    }
                    else
                    {
                        validationMessage = "Please upload a valid Excel file.";
                    }
                }
                else
                {
                    validationMessage = "Please upload a valid Excel file.";
                }
            }
            catch (Exception ex)
            {
                validationMessage = "Successfully Uploaded";
            }

            return Json(new { data = validationMessage, status = result }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpPost]
        public JsonResult CreateEvent(string Year)
        {
            Project HackProject = new Project();
            string result = string.Empty;
            string projectName = "Hackathon_" + Year;
            try
            {
                using (var context = new OrgHackEntities())
                {
                    var ProjectId = (from projects in context.Projects where projects.ProjectName == projectName select projects.ProjectId).FirstOrDefault();
                    if(ProjectId <= 0)
                    {
                        HackProject.ProjectName = projectName;
                        HackProject.CreatedDate = DateTime.Now;
                        HackProject.IsActive = true;
                        context.Projects.Add(HackProject);
                        context.SaveChanges();
                        result = "Successfully Created!!";
                    }
                    else
                    {
                        result = "Event Name Exists. Please check and rename the Eventname";
                        return Json(new { Message = result, status = false }, JsonRequestBehavior.AllowGet);
                    }
                   
                }
            }
            catch(Exception Ex)
            {
                result = "An error occured while processing the data. Please try again later";
                return Json(new { Message = result, status = false }, JsonRequestBehavior.AllowGet);
            }
            
            return Json(new { Message = result , status = true}, JsonRequestBehavior.AllowGet);
        }

    }
}