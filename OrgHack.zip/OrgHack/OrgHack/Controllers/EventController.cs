﻿using OrgHack.Entity;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using OrgHack.Models;

namespace OrgHack.Controllers
{
    public class EventController : Controller
    {
        public ActionResult Index()
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            ViewBag.TeamName = (from project in orgHackEntities.Projects
                                where project.ProjectName.Contains(DateTime.Now.Year.ToString())
                                join teams in orgHackEntities.Teams on project.ProjectId equals teams.ProjectId
                                where teams.IsActive.Value == true
                                select teams).GroupBy(x => x.TeamId).Select(x => x.FirstOrDefault()).ToList().OrderBy(x => x.TeamId).ToDictionary(key => key.TeamId.ToString(), value => value.TeamName);

            ViewBag.TeamName = new SelectList(ViewBag.TeamName, "Key", "Value");
            ViewBag.Role = MemberRoles.getUserRole(HttpContext.User.Identity.Name);
            return View();
        }

        [HttpPost]
        public JsonResult EmployeeList()
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            orgHackEntities.Configuration.ProxyCreationEnabled = false;
            var employeeList = (from employee in orgHackEntities.Employees
                                where employee.IsActive.Value == true
                                select employee).ToList();

            return Json(new { result = employeeList, count = employeeList.Count }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetAvailableEmployeeList()
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            List<EmployeeDetail> employeeDetail = new List<EmployeeDetail>();
            orgHackEntities.Configuration.ProxyCreationEnabled = false;
            var employeeList = (from employee in orgHackEntities.Employees
                                where employee.IsActive.Value == true && !employee.Designation.Contains("Manager")
                                select employee).ToList();
            var memberList = (from totalEmployees in employeeList
                              join member in orgHackEntities.Members on totalEmployees.EmpId equals member.EmpId
                              where member.IsActive.Value
                              select member.EmpId).ToList();
            foreach (var item in employeeList)
            {
                EmployeeDetail selectedDetail = new EmployeeDetail();
                selectedDetail.EmployeeCode = item.EmployeeCode;
                selectedDetail.Emailid = item.Email;
                selectedDetail.EmployeeName = item.EmployeeName;
                selectedDetail.Designation = item.Designation;
                selectedDetail.Location = item.Location;
                selectedDetail.Status = memberList.Contains(item.EmpId) ? "Not Available" : "Available";

                employeeDetail.Add(selectedDetail);
            }

            return Json(new { result = employeeDetail, count = employeeDetail.Count }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult TeamLeadList()
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            orgHackEntities.Configuration.ProxyCreationEnabled = false;
            var teamLeadList = (from employee in orgHackEntities.Teams
                                where employee.IsActive.Value == true
                                select employee).ToList();
            return Json(new { result = teamLeadList, count = teamLeadList.Count }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult TeamMembersList()
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            var teamMemberList = (from employee in orgHackEntities.Members
                                  where employee.IsActive.Value == true
                                  select employee).ToList();
            return Json(new { result = teamMemberList, count = teamMemberList.Count }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetMyTeamDetails()
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            orgHackEntities.Configuration.ProxyCreationEnabled = false;
            int teamId = (from employee in orgHackEntities.Employees
                          where employee.Email == HttpContext.User.Identity.Name && employee.IsActive.Value == true
                          join member in orgHackEntities.Members on employee.EmpId equals member.EmpId
                          where member.IsActive.Value
                          select member.TeamId.Value).FirstOrDefault();
            var myTeamList = (from member in orgHackEntities.Members
                              where member.TeamId == teamId
                              join employee in orgHackEntities.Employees on member.EmpId equals employee.EmpId
                              where employee.IsActive.Value
                              select employee).ToList();
            var projectDetails = orgHackEntities.Teams.Where(x => x.TeamId == teamId).FirstOrDefault();
            string employeeName = string.Join(", ", from item in myTeamList select item.EmployeeName);
            ProjectDetails teamDetails = new ProjectDetails();
            teamDetails.EmployeeName = employeeName;
            teamDetails.TeamName = projectDetails.TeamName;
            teamDetails.SoftwareName = projectDetails.SoftwareName;
            teamDetails.SoftwareLink = projectDetails.SoftwareLink;
            teamDetails.SourceCodeLink = projectDetails.SourceCodeLink;
            teamDetails.DocumentationLink = projectDetails.DocumentationLink;
            teamDetails.VideoLink = projectDetails.VideoLink;
            List<ProjectDetails> teamProject = new List<ProjectDetails>();
            teamProject.Add(teamDetails);
            return Json(new { result = teamProject, count = teamProject.Count }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UpdateProjectDetails(string description, string softwareName, string softwareLink, string sourceCodeLink, string documentationLink, string videoLink)
        {
            if (Request.IsAuthenticated)
            {
                OrgHackEntities orgHackEntities = new OrgHackEntities();
                int teamId = (from employee in orgHackEntities.Employees
                              where employee.Email == HttpContext.User.Identity.Name && employee.IsActive.Value
                              join member in orgHackEntities.Members on employee.EmpId equals member.EmpId
                              where member.IsActive.Value
                              select member.TeamId.Value).FirstOrDefault();
                Team team = new Team();
                team = orgHackEntities.Teams.Where(x => x.TeamId == teamId).FirstOrDefault();
                if (team != null)
                {
                    team.SoftwareDescription = description;
                    team.SoftwareName = softwareName;
                    team.SoftwareLink = softwareLink;
                    team.SourceCodeLink = sourceCodeLink;
                    team.DocumentationLink = documentationLink;
                    team.VideoLink = videoLink;
                    team.ModifiedDate = DateTime.Now;
                    orgHackEntities.Teams.Attach(team);
                    orgHackEntities.Entry(team).Property(x => x.SoftwareDescription).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.SoftwareName).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.SoftwareLink).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.SourceCodeLink).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.DocumentationLink).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.VideoLink).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.ModifiedDate).IsModified = true;
                    orgHackEntities.Configuration.ValidateOnSaveEnabled = false;
                    orgHackEntities.SaveChanges();
                    return Json(true, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(false, JsonRequestBehavior.AllowGet);
        }

        public ActionResult MyTeamMembers()
        {
            return View();
        }

        public ActionResult GetProjectDetails()
        {
            return View("Formfield");
        }

        public ActionResult LeadBidDetails()
        {

            return View();
        }

        [HttpPost]
        public JsonResult UpdateMemberDetails(int teamId, string emailId)
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            int projectId = (from project in orgHackEntities.Projects
                             where project.ProjectName.Contains(DateTime.Now.Year.ToString())
                             select project.ProjectId).FirstOrDefault();

            var team = (from teams in orgHackEntities.Teams
                        where teams.TeamId == teamId && teams.ProjectId == projectId && teams.IsActive.Value == true
                        select teams).FirstOrDefault();

            var employee = (from employees in orgHackEntities.Employees
                            where employees.Email == emailId && employees.IsActive.Value == true
                            select employees).FirstOrDefault();

            Member member = new Member();
            member.EmpId = employee.EmpId;
            member.TeamId = team.TeamId;
            member.CreatedDate = DateTime.Now;
            member.ModifiedDate = DateTime.Now;
            member.IsActive = true;
            orgHackEntities.Members.Add(member);
            return Json(true, JsonRequestBehavior.AllowGet);
        }
    }

    public class ProjectDetails
    {
        public string EmployeeName { get; set; }
        public string TeamName { get; set; }
        public string SoftwareName { get; set; }
        public string SoftwareLink { get; set; }
        public string SourceCodeLink { get; set; }
        public string DocumentationLink { get; set; }
        public string VideoLink { get; set; }
    }
}