﻿using Newtonsoft.Json;
using OrgHack.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace OrgHack.Controllers
{
    public class UserController : Controller
    {

        public ActionResult Login()
        {
            return Redirect("/");
        }

        [HttpPost]
        public ActionResult Login(Login model, string returnUrl)
        {
            if (!TryUpdateModel(model)) return Json(new { res = "The email address or password provided is incorrect.", status = false });
           
            var result = Models.Login.GetAuthenticatedUserDetails(model.EmailId, model.Password);
            if (result > 0)
            {             
                if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                {                    
                    return Json(new { Url = returnUrl, status = true });
                }
                string userData = JsonConvert.SerializeObject(model);
                FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(1, model.EmailId, DateTime.Now, DateTime.Now.AddMinutes(15), false, userData);
                string enTicket = FormsAuthentication.Encrypt(authTicket);
                HttpCookie faCookie = new HttpCookie("authenticationcookie", enTicket);
                Response.Cookies.Add(faCookie);
                FormsAuthentication.SetAuthCookie(model.EmailId, false);
                string url = string.Empty;
                if (MemberRoles.getUserRole(model.EmailId) == (int)Models.Roles.Organizer) {
                    url ="/project";
                }
                else {
                    url = "/getemployee";
                }

                return Json(new { Url = url, status = true });
            }
            else
            {               
                return Json(new { res = "The email address or password provided is incorrect.", status = false }, JsonRequestBehavior.AllowGet);
            }            
        }

        [Authorize]
        public ActionResult LogOut()
        {
            HttpCookie cookie = new HttpCookie("authenticationcookie", "");
            cookie.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie);

            FormsAuthentication.SignOut();
            return Redirect("/");
        }
    }
}