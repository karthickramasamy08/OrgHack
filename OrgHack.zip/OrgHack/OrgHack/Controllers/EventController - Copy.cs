﻿using OrgHack.Entity;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace OrgHack.Controllers
{
    public class EventController : Controller
    {
        public ActionResult Index()
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            ViewBag.TeamName = (from project in orgHackEntities.Projects
                                where project.ProjectName.Contains(DateTime.Now.Year.ToString())
                                join teams in orgHackEntities.Teams on project.ProjectId equals teams.ProjectId
                                where teams.IsActive.Value == true
                                select teams).GroupBy(x => x.TeamId).Select(x => x.FirstOrDefault()).ToList().OrderBy(x => x.TeamId).ToDictionary(key => key.TeamId.ToString(), value => value.TeamName);
            return View();
        }

        [HttpPost]
        public JsonResult EmployeeList()
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            orgHackEntities.Configuration.ProxyCreationEnabled = false;
            var employeeList = (from employee in orgHackEntities.Employees
                                where employee.IsActive.Value == true
                                select employee).ToList();
            return Json(new { result = employeeList, count = employeeList.Count }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult TeamLeadList()
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            orgHackEntities.Configuration.ProxyCreationEnabled = false;
            var teamLeadList = (from employee in orgHackEntities.Teams
                                where employee.IsActive.Value == true
                                select employee).ToList();
            return Json(new { result = teamLeadList, count = teamLeadList.Count }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult TeamMembersList()
        {
            OrgHackEntities orgHackEntities = new OrgHackEntities();
            var teamMemberList = (from employee in orgHackEntities.Members
                                  where employee.IsActive.Value == true
                                  select employee).ToList();
            return Json(new { result = teamMemberList, count = teamMemberList.Count }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UpdateProjectDetails(string description, string softwareName, string softwareLink, string sourceCodeLink, string documentationLink, string videoLink)
        {
            if (Request.IsAuthenticated)
            {
                OrgHackEntities orgHackEntities = new OrgHackEntities();
                int teadId = (from employee in orgHackEntities.Employees
                              where employee.Email == HttpContext.User.Identity.Name && employee.IsActive.Value
                              join member in orgHackEntities.Members on employee.EmpId equals member.EmpId
                              where member.IsActive.Value
                              select member.TeamId.Value).FirstOrDefault();
                Team team = new Team();
                team = orgHackEntities.Teams.Where(x => x.TeamId == teadId).FirstOrDefault();
                if (team != null)
                {
                    team.SoftwareDescription = description;
                    team.SoftwareName = softwareName;
                    team.SoftwareLink = softwareLink;
                    team.SourceCodeLink = sourceCodeLink;
                    team.DocumentationLink = documentationLink;
                    team.VideoLink = videoLink;
                    team.ModifiedDate = DateTime.Now;
                    orgHackEntities.Teams.Attach(team);
                    orgHackEntities.Entry(team).Property(x => x.SoftwareDescription).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.SoftwareName).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.SoftwareLink).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.SourceCodeLink).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.DocumentationLink).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.VideoLink).IsModified = true;
                    orgHackEntities.Entry(team).Property(x => x.ModifiedDate).IsModified = true;
                    orgHackEntities.Configuration.ValidateOnSaveEnabled = false;
                    orgHackEntities.SaveChanges();
                    return Json(true, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(false, JsonRequestBehavior.AllowGet);
        }

        public ActionResult MyTeamMembers()
        {
            return View();
        }

        public ActionResult GetProjectDetails()
        {
            return View("Formfield");
        }
    }
}