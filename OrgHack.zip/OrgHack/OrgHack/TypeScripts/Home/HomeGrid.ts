﻿﻿import { Grid, Page, Toolbar, Filter, SortDirection, Sort, QueryCellInfoEventArgs, CheckBoxChangeEventArgs, Edit, EditEventArgs, EJ2Intance, Selection, FilterType } from '@syncfusion/ej2-grids';
import { Tab } from '@syncfusion/ej2-navigations';
import { ClickEventArgs } from '@syncfusion/ej2-navigations';
import { DataManager, Query, UrlAdaptor } from '@syncfusion/ej2-data';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Button } from '@syncfusion/ej2-buttons';
import { Dialog } from '@syncfusion/ej2-popups';
import { enableRipple } from '@syncfusion/ej2-base';
enableRipple(true);
import { MultiSelect, FilteringEventArgs } from '@syncfusion/ej2-dropdowns';
import { CheckBox, ChangeEventArgs } from '@syncfusion/ej2-buttons';

let grid: Grid;
let isWebInstaller = false;

// Ready fuction
$(document).ready(function () {    
    getEmployeeDetails();
})

function getEmployeeDetails() {
    // Initialize grid
    //let query: Query = new Query().addParams('BuildName', window.location.pathname.split('/')[2]).addParams('VersionNumber', window.location.pathname.split('/')[3]).addParams('HasWebInstaller', isWebInstaller);
    let data = new DataManager({
        url: '/getemployee/list',
        adaptor: new UrlAdaptor
    });

    Grid.Inject(Page, Filter, Toolbar);
    let gridColumns = [
        { headerText: "EmployeeId", field: "EmployeeId", visible: false },
        { headerText: "Code", field: "EmployeeCode", width: '50', textAlign: 'Left', type: 'string' },
        { headerText: "EMail", field: "Email", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Employee Name", field: "EmployeeName", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Designation", field: "Designation", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Location", field: "Location", width: '90', textAlign: 'Left', type: 'string' },      
        { type: 'checkbox', allowFiltering: false, allowSorting: false, width: '50' },
    ]
    grid = new Grid({
        dataSource: data,
        toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel'],
        allowTextWrap: true,
        allowFiltering: true,
        allowSelection: true,
        columns: gridColumns,
        allowPaging: true,
        allowResizing: true,
        pageSettings: { pageSize: 20 }
    });
    grid.appendTo('#grid');

    
}
