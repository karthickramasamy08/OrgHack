﻿﻿import { Grid, Page, Toolbar, Filter, SortDirection, Sort, QueryCellInfoEventArgs, CheckBoxChangeEventArgs, Edit, EditEventArgs, EJ2Intance, Selection, FilterType, Column } from '@syncfusion/ej2-grids';
import { Tab } from '@syncfusion/ej2-navigations';
import { ClickEventArgs } from '@syncfusion/ej2-navigations';
import { DataManager, Query, UrlAdaptor } from '@syncfusion/ej2-data';
import { DropDownList, ChangeEventArgs } from '@syncfusion/ej2-dropdowns';
import { Button } from '@syncfusion/ej2-buttons';
import { Dialog } from '@syncfusion/ej2-popups';
import { enableRipple } from '@syncfusion/ej2-base';
enableRipple(true);
import { MultiSelect, FilteringEventArgs } from '@syncfusion/ej2-dropdowns';

let grid: Grid;
let productIdElem: HTMLElement;
let productIdObj: DropDownList;
let teamName = '';

// Ready fuction
$(document).ready(function () {    
    getEmployeeDetails(false);
})

function getEmployeeDetails(HasLead) {
    if (HasLead) {
        let data = new DataManager({
            url: '/getteamlead/list',
            adaptor: new UrlAdaptor
        });

        Grid.Inject(Page, Filter, Toolbar);
        let gridColumns = [
            { headerText: "TeamId", field: "TeamId", visible: false },
            { headerText: "Team Name", field: "TeamDisplayName", width: '90', type: 'string' },
            { headerText: "Software Name", field: "SoftwareName", width: '90', textAlign: 'Left', type: 'string' },
            { headerText: "Description", field: "SoftwareDescription", width: '90', textAlign: 'Left', type: 'string' },
            { headerText: "Software Link", field: "SoftwareLink", width: '90', textAlign: 'Left', type: 'string' },
            { headerText: "Software Code Link", field: "SoftwareCodeLink", width: '90', textAlign: 'Left', type: 'string' },
            { headerText: "Documentation Link", field: "DocumentationLink", width: '90', textAlign: 'Left', type: 'string' },
            { headerText: "Video Link", field: "VideoLink", width: '90', textAlign: 'Left', type: 'string' }
        ]

        grid = new Grid({
            dataSource: data,
            editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal' },
            toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel'],
            allowTextWrap: true,
            allowFiltering: true,
            allowSelection: true,
            columns: gridColumns,
            allowPaging: true,
            allowResizing: true,
            pageSettings: { pageSize: 20 },
            actionComplete: (args: EditEventArgs) => {
                if (args.requestType === 'save') {
                    alert("save");
                }
            },
        });
    }
    else {
        // Initialize grid    
        let data = new DataManager({
            url: '/getavailableemployee/list',
            adaptor: new UrlAdaptor
        });

        Grid.Inject(Edit, Page, Filter, Toolbar);
        let gridColumns = [
            { headerText: "Code", field: "EmployeeCode", width: '50', textAlign: 'Left', type: 'string' },
            { headerText: "EMail", field: "Emailid", width: '90', textAlign: 'Left', type: 'string' },
            { headerText: "Employee Name", field: "EmployeeName", width: '90', textAlign: 'Left', type: 'string' },
            { headerText: "Designation", field: "Designation", width: '90', textAlign: 'Left', type: 'string' },
            { headerText: "Location", field: "Location", width: '90', textAlign: 'Left', type: 'string' },
            { headerText: "Status", field: "Status", width: '90', textAlign: 'Left', type: 'string' },
            {
                headerText: "Team Name", field: "TeamName", width: '100', type: 'string', editType: 'dropdownedit', edit: {
                    create: () => {
                        productIdElem = document.createElement('input');
                        return productIdElem;
                    },
                    read: () => {
                        teamName = productIdObj.value.toString();
                        return productIdObj.text;
                    },
                    destroy: () => {
                        productIdObj.destroy();
                    },
                    write: (args: { rowData: Object, column: Column }) => {
                        productIdObj = new DropDownList({
                            dataSource: (<any>window).teamLeadList,
                            sortOrder: "Ascending",
                            fields: { value: 'Value', text: 'Text' },
                            enabled: true,
                            text: args.rowData[args.column.field]

                        });
                        productIdObj.appendTo(productIdElem);
                    }
                }
            }
        ]
        if ((<any>window).userRole == 1 || (<any>window).userRole == 2) {
            grid = new Grid({
                dataSource: data,
                editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal' },
                toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel'],
                allowTextWrap: true,
                allowFiltering: true,
                allowSelection: true,
                columns: gridColumns,
                allowPaging: true,
                allowResizing: true,
                pageSettings: { pageSize: 20 },
                actionComplete: (args: EditEventArgs) => {
                    if (args.requestType === 'save') {
                        UpdateMemberEntry(teamName, args.rowData['Emailid']);
                    }
                },
            });
        } else {
            grid = new Grid({
                dataSource: data,
                allowTextWrap: true,
                allowFiltering: true,
                allowSelection: true,
                columns: gridColumns,
                allowPaging: true,
                allowResizing: true,
                pageSettings: { pageSize: 20 },
                actionComplete: (args: EditEventArgs) => {
                    if (args.requestType === 'save') {
                        UpdateMemberEntry(teamName, args.rowData['Emailid']);
                    }
                },
            });
        }
    }
    
    grid.appendTo('#grid');
}

$(document).on("click", "#tabs-selection span", function () {
    $('#grid').html('');
    $("#tabs-selection span").removeClass('active');
    $(this).addClass('active');
    if ($(this).attr('id') == "all-members") {
        getEmployeeDetails(false);
    } else if ($(this).attr('id') == "my-teams") {
        getMyTeams();
    } else {
        getEmployeeDetails(true);
    }
})

function getMyTeams() {
    let data = new DataManager({
        url: '/getteamdetails',
        adaptor: new UrlAdaptor
    });

    Grid.Inject(Edit, Page, Filter, Toolbar);
    let gridColumns = [
        { headerText: "TeamName", field: "TeamName", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Members", field: "EmployeeName", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "SoftwareName", field: "SoftwareName", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "SoftwareLink", field: "SoftwareLink", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "SourceCodeLink", field: "SourceCodeLink", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "DocumentationLink", field: "DocumentationLink", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "VideoLink", field: "VideoLink", width: '90', textAlign: 'Left', type: 'string' },
    ]
    if ((<any>window).userRole == 2) {
        grid = new Grid({
            dataSource: data,
            editSettings: { allowEditing: true, allowAdding: false, allowDeleting: false, mode: 'Normal' },
            toolbar: ['Edit', 'Update', 'Cancel'],
            allowTextWrap: true,
            allowFiltering: true,
            allowSelection: true,
            columns: gridColumns,
            allowPaging: true,
            allowResizing: true,
            pageSettings: { pageSize: 20 },
            actionComplete: (args: EditEventArgs) => {
                if (args.requestType === 'save') {
                    alert("save");
                }
            },
        });
    } else {
        grid = new Grid({
            dataSource: data,
            allowTextWrap: true,
            allowFiltering: true,
            allowSelection: true,
            columns: gridColumns,
            allowPaging: true,
            allowResizing: true,
            pageSettings: { pageSize: 20 },
            actionComplete: (args: EditEventArgs) => {
                if (args.requestType === 'save') {
                    alert("save");
                }
            },
        });
    }
    grid.appendTo('#grid');
}

function UpdateMemberEntry(teamValue, email) {
    $.ajax({
        type: 'POST',
        url: "/updatememberdetails",
        data: { teamId: teamValue, emailId: email },
        cache: true,
        success: function (result) {
            if (result == true) {
                grid.refresh();
            }
            else {
                location.href = "/form-submit";
            }
        }
    });
}