"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ej2_grids_1 = require("@syncfusion/ej2-grids");
var ej2_data_1 = require("@syncfusion/ej2-data");
var ej2_dropdowns_1 = require("@syncfusion/ej2-dropdowns");
var ej2_base_1 = require("@syncfusion/ej2-base");
ej2_base_1.enableRipple(true);
var grid;
var productIdElem;
var productIdObj;
// Ready fuction
$(document).ready(function () {
    getEmployeeDetails();
});
function getEmployeeDetails() {
    // Initialize grid    
    var data = new ej2_data_1.DataManager({
        url: '/getemployee/list',
        adaptor: new ej2_data_1.UrlAdaptor
    });
    ej2_grids_1.Grid.Inject(ej2_grids_1.Edit, ej2_grids_1.Page, ej2_grids_1.Filter, ej2_grids_1.Toolbar);
    var gridColumns = [
        { headerText: "EmployeeId", field: "EmployeeId", visible: false },
        { headerText: "Code", field: "EmployeeCode", width: '50', textAlign: 'Left', type: 'string' },
        { headerText: "EMail", field: "Email", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Employee Name", field: "EmployeeName", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Designation", field: "Designation", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Location", field: "Location", width: '90', textAlign: 'Left', type: 'string' },
        {
            headerText: "Team Name", field: "TeamName", width: '100', type: 'string', editType: 'dropdownedit', edit: {
                create: function () {
                    productIdElem = document.createElement('input');
                    return productIdElem;
                },
                read: function () {
                    return productIdObj.text;
                },
                destroy: function () {
                    productIdObj.destroy();
                },
                write: function (args) {
                    productIdObj = new ej2_dropdowns_1.DropDownList({
                        dataSource: window.teamLeadList,
                        sortOrder: "Ascending",
                        fields: { value: 'TeamId', text: 'TeamName' },
                        enabled: true,
                        text: args.rowData[args.column.field],
                    });
                    productIdObj.appendTo(productIdElem);
                }
            }
        }
    ];
    grid = new ej2_grids_1.Grid({
        dataSource: data,
        editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal' },
        toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel'],
        allowTextWrap: true,
        allowFiltering: true,
        allowSelection: true,
        columns: gridColumns,
        allowPaging: true,
        allowResizing: true,
        pageSettings: { pageSize: 20 }
    });
    grid.appendTo('#grid');
}
$(document).on("click", "#tabs-selection span", function () {
    $('#grid').html('');
    $("#tabs-selection span").removeClass('active');
    $(this).addClass('active');
    if ($(this).attr('id') == "all-members") {
        getEmployeeDetails();
    }
    else {
        getTeamLeadDetails();
    }
});
function getTeamLeadDetails() {
    // Initialize grid
    var data = new ej2_data_1.DataManager({
        url: '/getteamlead/list',
        adaptor: new ej2_data_1.UrlAdaptor
    });
    ej2_grids_1.Grid.Inject(ej2_grids_1.Page, ej2_grids_1.Filter, ej2_grids_1.Toolbar);
    var gridColumns = [
        { headerText: "TeamId", field: "TeamId", visible: false },
        { headerText: "Team Name", field: "TeamDisplayName", type: 'string' },
        { headerText: "Software Name", field: "SoftwareName", width: '50', textAlign: 'Left', type: 'string' },
        { headerText: "Description", field: "SoftwareDescription", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Software Link", field: "SoftwareLink", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Software Code Link", field: "SoftwareCodeLink", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Documentation Link", field: "DocumentationLink", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Video Link", field: "VideoLink", width: '90', textAlign: 'Left', type: 'string' },
        { headerText: "Status", field: "Completed", width: '90', textAlign: 'Left', type: 'string' },
    ];
    grid = new ej2_grids_1.Grid({
        dataSource: data,
        allowTextWrap: true,
        allowFiltering: true,
        allowSelection: true,
        columns: gridColumns,
        allowPaging: true,
        allowResizing: true,
        pageSettings: { pageSize: 20 }
    });
    grid.appendTo('#grid');
}
//# sourceMappingURL=TeamSelection.js.map