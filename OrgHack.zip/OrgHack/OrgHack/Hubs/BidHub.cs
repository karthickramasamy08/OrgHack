﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;

namespace OrgHack.Hubs
{
    public class BidHub: Hub
    {
        public void SendNotifications(string email)
        {
            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<BidHub>();
            //List<CommonModel> status = BigdataModel.GetStatusNotifications(int.Parse(customerId));
            context.Clients.All.getStatus("You will be shown all");
        }
    }
}