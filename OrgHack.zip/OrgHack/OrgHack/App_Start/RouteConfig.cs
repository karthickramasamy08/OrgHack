﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace OrgHack
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            
            routes.MapRoute(
               name: "memberslist", // Route name
               url: "getemployee", // URL with parameters
                 defaults: new { controller = "Event", action = "Index" }
           );

            routes.MapRoute(
               name: "leadbid", // Route name
               url: "leadbid", // URL with parameters
                 defaults: new { controller = "Event", action = "LeadBidDetails" }
           );

            routes.MapRoute(
               name: "Employeelist", // Route name
               url: "getemployee/list", // URL with parameters
                 defaults: new { controller = "Event", action = "EmployeeList" }
           );

            routes.MapRoute(
               name: "GetAvailableEmployeeList", // Route name
               url: "getavailableemployee/list", // URL with parameters
                 defaults: new { controller = "Event", action = "GetAvailableEmployeeList" }
           );

            routes.MapRoute(
               name: "TeamLeadlist", // Route name
               url: "getteamlead/list", // URL with parameters
                 defaults: new { controller = "Event", action = "TeamLeadList" }
           );

            routes.MapRoute(
               name: "UploadEmployeesinTable",
               url: "uploademployees/data/{file}",
               defaults: new { controller = "Employees", action = "UploadEmployee", file = UrlParameter.Optional }
           );


            routes.MapRoute(
                name: "CreateProject",
                url: "project",
                defaults: new { controller = "Employees", action = "AddUser" }
            );

            routes.MapRoute(
               name: "EventCreation",
               url: "create/event/{year}",
               defaults: new { controller = "Employees", action = "CreateEvent", year = UrlParameter.Optional }
           );

            routes.MapRoute(
               name: "teammember", // Route name
               url: "myteams", // URL with parameters
                 defaults: new { controller = "Event", action = "MyTeamMembers" }
           );

            routes.MapRoute(
               name: "formSubmission", // Route name
               url: "form-submit", // URL with parameters
                 defaults: new { controller = "Event", action = "GetProjectDetails" }
           );

            routes.MapRoute(
              name: "GetMyTeam", // Route name
              url: "getteamdetails", // URL with parameters
                defaults: new { controller = "Event", action = "GetMyTeamDetails" }
          );

            routes.MapRoute(
               name: "updateProject", // Route name
               url: "updateprojectdetails", // URL with parameters
                 defaults: new { controller = "Event", action = "UpdateProjectDetails" }
           );

            routes.MapRoute(
               name: "Login", // Route name
               url: "login", // URL with parameters
                 defaults: new { controller = "User", action = "Login" }
           );

            routes.MapRoute(
               name: "UpdateMemberDetails", // Route name
               url: "updatememberdetails", // URL with parameters
                 defaults: new { controller = "Event", action = "UpdateMemberDetails" }
           );

            routes.MapRoute(
               name: "Default",
               url: "{controller}/{action}/{id}",
               defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
           );
        }
    }
}
