﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace OrgHack
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
               name: "memberslist", // Route name
               url: "getemployee", // URL with parameters
                 defaults: new { controller = "Event", action = "Index" }
           );

            routes.MapRoute(
               name: "Employeelist", // Route name
               url: "getemployee/list", // URL with parameters
                 defaults: new { controller = "Event", action = "EmployeeList" }
           );

            routes.MapRoute(
               name: "TeamLeadlist", // Route name
               url: "getteamlead/list", // URL with parameters
                 defaults: new { controller = "Event", action = "TeamLeadList" }
           );

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
