﻿function showNotification(statusList) {
    alert(statusList);
}