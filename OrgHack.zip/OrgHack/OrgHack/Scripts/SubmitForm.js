﻿$(document).ready(function () {
    $("#project-submit-btn").click(function () {
        location.href = "/form-submit";
    })
})

function onsubmitvalidation() {
    var project_description = $("#text-description").val();
    var software_name = $("#text-software-name").val();
    var software_link = $("#text-software-link").val();
    var source_link = $("#text-source-link").val();
    var document_link = $("#text-document-link").val();
    var video_link = $("#text-video-link").val();
    var validationError = false;
    var project_Description = $("#text-description").val();
    if (project_description == "" || project_description == null || project_description.trim().length < 1) {
        validationError = false;
        $("#validation-description").removeClass("hide");
    }
    else
    {
        validationError = true;
        $("#validation-description").addClass("hide");
    }

    var formDetails = { description: project_description, softwareName: software_name, softwareLink: software_link, sourceCodeLink: source_link, documentationLink: document_link, videoLink: video_link }
    if (validationError)
    {
        $.ajax({
                type: 'POST',
                url: "/updateprojectdetails",
                data: formDetails,
                cache: true,
                success: function (result)
                {
                    if (result == true) {
                        location.href = "/getemployee";
                    }
                    else {
                        location.href = "/form-submit";
                    }
                },
                Error: function ()
                {
                    location.href = "/form-submit";
                }
        });
    }
}